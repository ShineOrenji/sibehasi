<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Anggota;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Buat User Admin
        User::create([
            'name' => 'Admin Bendahara',
            'email' => 'admin@sibehasi.com',
            'password' => Hash::make('password'),
            'role' => 'admin',
        ]);

        // 2. Buat User Ketua
        User::create([
            'name' => 'Ketua HIMASI',
            'email' => 'ketua@sibehasi.com',
            'password' => Hash::make('password'),
            'role' => 'ketua',
        ]);

        // 3. Buat User Mahasiswa + Profil Anggota
        $mahasiswa = User::create([
            'name' => 'Fahmi Mahasiswa',
            'email' => 'fahmi@sibehasi.com',
            'password' => Hash::make('password'),
            'role' => 'mahasiswa',
        ]);

        Anggota::create([
            'user_id' => $mahasiswa->id,
            'nim' => '24050003',
            'angkatan' => '2024',
            'no_hp' => '08123456789',
        ]);
    }
}
