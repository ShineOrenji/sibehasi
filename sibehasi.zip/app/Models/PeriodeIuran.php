<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

    class PeriodeIuran extends Model
    {
        protected $table = 'periode_iuran';
        protected $fillable = ['kategori_id', 'nama_periode', 'nominal', 'denda', 'tanggal_mulai', 'deadline_pembayaran', 'status'];

        public function kategori()
        {
            return $this->belongsTo(KategoriTransaksi::class, 'kategori_id');
        }

        // Untuk menghitung siapa saja yang sudah bayar
        public function pembayaran()
        {
            return $this->hasMany(PembayaranIuran::class, 'periode_id');
        }

        // Fungsi ajaib untuk menghitung denda otomatis
        public function getNominalAkhirAttribute()
        {
            // PADA BAGIAN INI KITA GUNAKAN deadline_pembayaran
            if ($this->deadline_pembayaran && now()->startOfDay()->greaterThan($this->deadline_pembayaran) && $this->denda > 0) {
                return $this->nominal + $this->denda;
            }
            return $this->nominal;
        }
    }